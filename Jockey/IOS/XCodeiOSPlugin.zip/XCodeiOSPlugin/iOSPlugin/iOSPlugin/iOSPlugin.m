//
//  iOSPlugin.m
//  iOSPlugin
//
//  Created by Bao Tran on 1/4/16.
//  Copyright © 2016 Bao Tran. All rights reserved.
//

#import "iOSPlugin.h"

@implementation iOSPlugin

@end
